﻿using UnityEngine;

public class ExcludeTeleport : MonoBehaviour
{
}